import pygame
import os
from gameobjects.vector2 import Vector2

background = "resources/ledena_doba.jpg"

pygame.init()

screen = pygame.display.set_mode((800,600),0,32)

class Level(object):
    def __init__(self):
        
        #Background
        self.ledena_doba = pygame.image.load(background).convert()
        self.ledena_doba = pygame.transform.scale(self.ledena_doba,(800,600))
      
    

